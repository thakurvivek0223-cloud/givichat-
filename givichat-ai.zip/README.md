# GiviChat.ai
A simple Omegle-like platform to connect people via video chat based on location and gender filters.
