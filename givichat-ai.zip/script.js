document.getElementById("startChat").addEventListener("click", function() {
    alert("Video Chat feature coming soon!");
});
